import React from 'react'

export const TutorialIndex = () => {
  return (
    <div>TutorialIndex</div>
  )
}
