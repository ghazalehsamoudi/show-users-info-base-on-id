import axios from "axios";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { BASE_URL } from "../../utils/constants";
export const UserInfoIndex = () => {
  const { id } = useParams();
  const [userDetail, setUserDetail] = useState(null);
  useEffect(() => {
    // const getDetails = async () => {
    //   try {
    //     const response = await axios.get(
    //       `https://jsonplaceholder.typicode.com/users/${id}`
    //     );
    //     setUserDetail(response.data);
    //   } catch (error) {
    //     console.log(error);
    //   }
    // };
    // getDetails();
    axios
      .get(`${BASE_URL}/users/${id}`)
      .then((response) => {
        // console.log(response.data);
        setUserDetail(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, [id]);
  //   console.log(userDetail);
  return (
    <div className='container'>
      <h2 className='my-3'>user details</h2>
      {userDetail ? (
        <ul className='list-unstyled p-3 rounded-3 user-card'>
          <li className='d-flex'>
            <strong className='user-detail-title'>name: </strong>
            <span>{userDetail.firstName} {userDetail.lastName}</span>
          </li>
          <li className='d-flex'>
            <strong className='user-detail-title'>username: </strong>
            <span>{userDetail.username}</span>
          </li>
          <li className='d-flex'>
            <strong className='user-detail-title'>email: </strong>
            <span>{userDetail.email}</span>
          </li>
          <li className='d-flex'>
            <strong className='user-detail-title'> phone: </strong>
            <span>{userDetail.phone}</span>
          </li>
          <li className='d-flex'>
            <strong className='user-detail-title'>address: </strong>
            <p className='mb-0'>
              {userDetail.address.city}
              {userDetail.address.postalCode}
              {userDetail.address.state}
            </p>
          </li>
          <li className='d-flex'>
            <strong className='user-detail-title'>company: </strong>
            <p className='mb-0'>
              {userDetail.company.department} 
              {userDetail.company.name} 
              {userDetail.company.title}
            </p>
          </li>
        </ul>
      ) : (
        <p>users is empty</p>
      )}
    </div>
  );
};
