import React from "react";
import { Link } from "react-router-dom";

export const UserCard = ({
  id,
  firstName,
  lastName,
  username,
  email,
  phone,
}) => {
  return (
    <div className='col-12 col-sm-6 col-lg-4'>
      <ul className='list-unstyled p-3 rounded-3 user-card'>
        <li className='fs-5 fw-bold text-center mb-2 '>
          {firstName} {lastName}
        </li>
        <li>username: {username}</li>
        <li>email: {email}</li>
        <li>phone: {phone}</li>
        <li>
          <Link to={id.toString()}>view all</Link>
        </li>
      </ul>
    </div>
  );
};
