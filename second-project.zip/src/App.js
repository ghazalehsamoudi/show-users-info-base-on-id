import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Layout } from "./components/layout";
import { HomeIndex } from "./pages/home";
import { TutorialIndex } from "./pages/tutorials";
import { Users } from "./pages/users";
import { UserInfoIndex } from "./pages/users/user-info";

export const App = () => {
  return (
      <BrowserRouter>
        <Layout>
          <Routes>
            <Route path='/' element={<HomeIndex />} />
            <Route path='tutorials' element={<TutorialIndex />} />
            <Route path='users' element={<Users />} />
            <Route path='users/:id' element={<UserInfoIndex/>} />
          </Routes>
        </Layout>
      </BrowserRouter>
  );
};
